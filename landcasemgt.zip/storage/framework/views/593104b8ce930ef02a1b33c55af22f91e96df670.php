
<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
    <div class="container-fluid py-4">
        <?php if($list_mode): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.caselist', [])->html();
} elseif ($_instance->childHasBeenRendered('l4046487236-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l4046487236-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4046487236-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4046487236-0');
} else {
    $response = \Livewire\Livewire::mount('components.caselist', []);
    $html = $response->html();
    $_instance->logRenderedChild('l4046487236-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php else: ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.caseform', [])->html();
} elseif ($_instance->childHasBeenRendered('l4046487236-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l4046487236-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4046487236-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4046487236-1');
} else {
    $response = \Livewire\Livewire::mount('components.caseform', []);
    $html = $response->html();
    $_instance->logRenderedChild('l4046487236-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endif; ?>
</div>
</main>
<?php /**PATH C:\laragon\www\landcasemgt\resources\views/livewire/pages/casemgt.blade.php ENDPATH**/ ?>