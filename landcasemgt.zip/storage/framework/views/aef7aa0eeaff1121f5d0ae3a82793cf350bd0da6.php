<div class="d-flex flex-column justify-content-center align-items-center homepage-content">
    <div class="h-100">
        <h5 class="mb-1">
            কেইস বিস্তারিত
        </h5>

      </div>
      <br>

    <p class=""><span class="font-weight-bold">নামঃ </span>রাফায়েতুল কবীর</p>
    <p class=""><span class="font-weight-bold">মোবাইলঃ </span>০১৭XXXXXXXX</p>
    <p class=""><span class="font-weight-bold">ইমেইলঃ </span>demo@demo.com</p>
    <p class=""><span class="font-weight-bold">কেইস নংঃ </span><?php echo e($case); ?></p>

    <p class=""><span class="font-weight-bold">কেইস বিবরণ </span></p>
    <div class="container" style="padding-left: 9rem; padding-right: 9rem;">
    <p class="">ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা ডেমো ডাটা </p>
    </div>

    <p class=""><span class="font-weight-bold">কেইস এর বর্তমান অবস্থাঃ </span>ULAO/ULSAO-এর নিকট রিপোর্ট এর জন্যে দেয়া হয়েছে</p>
    <p class=""><span class="font-weight-bold">পরবর্তী তারিখঃ </span>৫ জুলাই, ২০২২</p>
    
    <div class="text-center">
        <button type="input" class="btn bg-gradient-info w-100 my-4 mb-2"  wire:click="gotohome">ঠিক আছে</button>
    </div>

</div>
<?php /**PATH C:\laragon\www\landcasemgt\resources\views/livewire/pages/status.blade.php ENDPATH**/ ?>