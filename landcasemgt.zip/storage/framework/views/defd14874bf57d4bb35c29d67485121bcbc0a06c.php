<div class="row">
    <div class="col-md-6">
      <div class="input-group input-group-outline mb-3">
        <input type="text" placeholder="কেইস নাম্বার" wire:model="number" class="form-control" required>
      </div>
      <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger alert-dismissible text-white" role="alert">
            <span class="text-sm"><?php echo e($message); ?></span>
            
        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>
    <div class="col-md-6">
      <div class="input-group input-group-outline mb-3">
        <select class="form-select form-control" wire:model="selected_type" aria-label="Default select example">
            <option selected>কেইস এর ধরণ নির্বাচন করুন</option>
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <?php $__errorArgs = ['selected_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger alert-dismissible text-white" role="alert">
            <span class="text-sm">কেইস এর ধরণটি ঠিকভাবে নির্বাচন করুন!</span>
        </div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
  </div>


  <div class="input-group input-group-outline mb-3">
    <input type="text" placeholder="কেইস শিরোনাম (যদি প্রযোজ্য হয়)" wire:model="title" class="form-control">
  </div>

  <div class="input-group input-group-outline mb-3">
    <textarea placeholder="কেইস বর্ণনা (যদি প্রযোজ্য হয়)" wire:model="description" class="form-control"></textarea>
  </div>

  <div class="row">
    <div class="col-md-6">
      <div class="input-group input-group-outline mb-3">
        <select class="form-select form-control" wire:model="selected_type" aria-label="Default select example">
            <option selected>কেইস এর বর্তমান অবস্থা বাছুন</option>
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <?php $__errorArgs = ['selected_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger alert-dismissible text-white" role="alert">
            <span class="text-sm">কেইস এর ধরণটি ঠিকভাবে নির্বাচন করুন!</span>
        </div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6">
      <div class="input-group input-group-outline mb-3">
        <input type="text" placeholder="কেইস এর পরবর্তী তারিখ" wire:model="number" class="form-control" required>
      </div>
      <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger alert-dismissible text-white" role="alert">
            <span class="text-sm"><?php echo e($message); ?></span>
            
        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>

  </div>
<?php /**PATH C:\laragon\www\landcasemgt\resources\views/components/case-form.blade.php ENDPATH**/ ?>