
<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">

    <div class="container-fluid py-4">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('statrow', [])->html();
} elseif ($_instance->childHasBeenRendered('l3293447028-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3293447028-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3293447028-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3293447028-0');
} else {
    $response = \Livewire\Livewire::mount('statrow', []);
    $html = $response->html();
    $_instance->logRenderedChild('l3293447028-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</main>
<?php /**PATH C:\laragon\www\landcasemgt\resources\views/livewire/pages/dashboard.blade.php ENDPATH**/ ?>