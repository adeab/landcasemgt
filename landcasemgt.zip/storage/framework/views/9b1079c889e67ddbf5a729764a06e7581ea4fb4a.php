<nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">
    <div class="container-fluid py-1 px-3">
      <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
          <?php if(Request::path()!="/" AND !Str::contains(Request::path(), 'dashboard')): ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.navlogo','data' => []]); ?>
<?php $component->withName('navlogo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
          <?php endif; ?>
        <div class="ms-md-auto pe-md-3 d-flex align-items-center">
          <ul class="navbar-nav  justify-content-end">
            <?php if(auth()->guard()->check()): ?>
            <li class="nav-item d-flex align-items-center">
                <?php if(!Str::contains(Request::path(), 'dashboard')): ?>
                <a href="<?php echo e(route('dashboard')); ?>" class="nav-link text-body font-weight-bold px-0" style="margin-left: 5px;">
                <i class="fa fa-tachometer  me-sm-1"></i>
                <span class="d-sm-inline d-none">ড্যাশবোর্ড</span>
                </a>
                <?php endif; ?>
            </li>
            <?php endif; ?>
              <li class="nav-item d-flex align-items-center">
                  <?php if(auth()->guard()->check()): ?>
                      <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>

                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'class' => 'nav-link text-body font-weight-bold px-0','onclick' => 'event.preventDefault();
                                            this.closest(\'form\').submit();']]); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'class' => 'nav-link text-body font-weight-bold px-0','onclick' => 'event.preventDefault();
                                            this.closest(\'form\').submit();']); ?>
                                            <i class="fa fa-power-off  me-sm-1"></i>
                            <?php echo e(__('লগ আউট')); ?>

                            
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </form>
                  <?php else: ?>
                      <a href="<?php echo e(route('login')); ?>" class="nav-link text-body font-weight-bold px-0">
                        <i class="fa fa-sign-in me-sm-1"></i>
                        <span class="d-sm-inline d-none">লগ ইন</span>
                      </a>
                      <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>" class="nav-link text-body font-weight-bold px-0" style="margin-left: 5px;">
                            <i class="fa fa-user me-sm-1"></i>
                            <span class="d-sm-inline d-none">Register</span>
                        </a>
                      <?php endif; ?>
                  <?php endif; ?>
              </li>
            </ul>
        </div>
      </div>
    </div>
  </nav>
<?php /**PATH C:\laragon\www\landcasemgt\resources\views/components/navbar.blade.php ENDPATH**/ ?>