<h1 <?php echo e($attributes); ?>>গৌড়নদী ভূমি অফিস</h1>
<?php /**PATH C:\laragon\www\landcasemgt\resources\views/components/project-title.blade.php ENDPATH**/ ?>