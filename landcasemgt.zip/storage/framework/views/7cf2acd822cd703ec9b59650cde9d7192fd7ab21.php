<div class="d-flex flex-column justify-content-center align-items-center homepage-content">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.project-logo','data' => ['class' => 'bd-gov-logo']]); ?>
<?php $component->withName('project-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'bd-gov-logo']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.project-title','data' => ['class' => 'logo-title']]); ?>
<?php $component->withName('project-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'logo-title']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <p class="sub-title">আপনার কেইস এর নাম্বার দিয়ে বর্তমান অবস্থা দেখুন</p>
    <form role="form" class="text-start" wire:submit.prevent="getCase">
        <div class="row">
            <div class="col-md-6">
              <div class="input-group input-group-outline mb-3">
                <input type="text" placeholder="কেইস নাম্বার" wire:model="case_number" class="form-control" required>
              </div>

            </div>
            <div class="col-md-6">
              <div class="input-group input-group-outline mb-3">
                <select class="form-select form-control" wire:model="selected_type" aria-label="Default select example">
                    <option selected>কেইস এর ধরণ</option>
                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

            </div>
          </div>


        <div class="text-center">
          <button type="submit" class="btn bg-gradient-primary w-100 my-4 mb-2">অবস্থা দেখুন</button>
        </div>

      </form>
</div>
<?php /**PATH C:\laragon\www\landcasemgt\resources\views/livewire/pages/welcome.blade.php ENDPATH**/ ?>