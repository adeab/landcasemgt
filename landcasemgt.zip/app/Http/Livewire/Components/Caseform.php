<?php

namespace App\Http\Livewire\Components;

use App\Models\CaseType;
use App\Models\LandCase;
use Livewire\Component;

class Caseform extends Component
{
    public $title;
    public $number;
    public $description;
    public $types;
    public $selected_type;

    public $plaintiffs;
    public $defendants;

    protected $rules=[
        'number'=>'required',
        'description'=>'',
        'title'=>'',
        'selected_type'=>'required|numeric',
        'plaintiffs'=>'',
        'defendants'=>''
    ];

    public function mount(){
        $this->types= CaseType::all();
        $this->plaintiffs = [
            [
            'name'=>'',
            'mobile'=>'',
            'address'=>''
            ]
        ];
        $this->defendants = [
            [
            'name'=>'',
            'mobile'=>'',
            'address'=>''
            ]
        ];
        // $this->defendants = [
        //     'name'=>'',
        //     'mobile'=>'',
        //     'address'=>''
        // ]

    }

    public function submit(){
        $validate_data = $this->validate();
        dd($validate_data);
        $caseid = LandCase::create($validate_data)->id;

    }
    public function addPlaintiff(){
        $this->plaintiffs[] =
            [
            'name'=>'',
            'mobile'=>'',
            'address'=>''
            ];
    }
    public function rmvPlaintiff($index){
        unset($this->plaintiffs[$index]);
        array_values($this->plaintiffs);
    }
    public function addDefendants(){
        $this->defendants[] =
            [
            'name'=>'',
            'mobile'=>'',
            'address'=>''
            ];
    }
    public function rmvDefendants($index){
        unset($this->defendants[$index]);
        array_values($this->defendants);
    }
    public function render()
    {
        return view('livewire.components.caseform');
    }
}
