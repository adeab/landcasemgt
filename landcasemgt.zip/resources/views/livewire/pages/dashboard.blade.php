
<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
{{-- <livewire:topbar /> --}}
    <div class="container-fluid py-4">
    <livewire:statrow />

    </div>
</main>
