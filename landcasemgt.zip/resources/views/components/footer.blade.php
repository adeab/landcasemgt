<footer class="footer">
    <div class="row">
        <div class="copyright text-center text-xs text-muted text-lg-start">
           Template © <a href="https://www.creative-tim.com" class="font-weight-bold" target="_blank">Creative Tim</a>
          </div>
    </div>

  </footer>
