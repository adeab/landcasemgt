<img {{ $attributes }} src="{{asset('images/bd-gov-logo.png')}}" class="bd-gov-logo">
