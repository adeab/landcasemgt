
<div class="d-flex flex-row  align-items-center" {{$attributes}}>
    <div class="">
        <x-project-logo class="bd-gov-logo-nav"/>
    </div>
    <div class="p-2">
        <x-project-title class="nav-title"/>
    </div>

  </div>
