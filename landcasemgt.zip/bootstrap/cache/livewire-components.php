<?php return array (
  'components.caseform' => 'App\\Http\\Livewire\\Components\\Caseform',
  'components.caselist' => 'App\\Http\\Livewire\\Components\\Caselist',
  'leftbar' => 'App\\Http\\Livewire\\Leftbar',
  'pages.casemgt' => 'App\\Http\\Livewire\\Pages\\Casemgt',
  'pages.dashboard' => 'App\\Http\\Livewire\\Pages\\Dashboard',
  'pages.status' => 'App\\Http\\Livewire\\Pages\\Status',
  'pages.welcome' => 'App\\Http\\Livewire\\Pages\\Welcome',
  'statrow' => 'App\\Http\\Livewire\\Statrow',
);